<?php $tag_id = 'ourteam_post_' .rand().time(); 
	$args = array(
		'post_type' => 'ourteam',
		'posts_per_page' => $numberposts,
		'post_status' => 'publish'
	);
 
	$query = new WP_Query($args);
?>
<?php if($query->have_posts()):?>
<div class="bwp-ourteam">
 <div class="block">
	<?php if (isset($title1) && $title1){ ?>	
	<div class="title-block">
		<?php echo '<h2>'. $title1 .'</h2>'; ?>
	</div>
	<?php } ?>
  <div class="block_content">
   <div id="<?php echo $tag_id; ?>" class="slick-carousel" data-dots="<?php echo $show_pag; ?>" data-nav="<?php echo esc_attr($show_nav);?>" data-slidesToScroll="true" data-columns4="<?php echo $columns4; ?>" data-columns3="<?php echo $columns3; ?>" data-columns2="<?php echo $columns2; ?>" data-columns1="<?php echo $columns1; ?>" data-columns="<?php echo $columns; ?>">
		<?php while($query->have_posts()):$query->the_post(); ?>
			<!-- Wrapper for slides -->
			<div class="ourteam-item">
				<div class="ourteam-items">
					<div class="ourteam-image">
						<?php the_post_thumbnail('full', array( 'class' => 'img-responsive' )) ?>
					</div>
					<div class="carousel-body ourteam-info">
						<?php 
							$team_job  = get_post_meta( get_the_ID(), 'team_job',true) ? get_post_meta( get_the_ID(), 'team_job',true) : '';				
						?>
						<div class="ourteam-customer-name"><?php the_title(); ?></div>
						<?php if($team_job): ?>	
						<div class="team-job"><?php echo esc_html($team_job); ?></div>
						<?php endif; ?>								
					</div>
				</div>
			</div>
		<?php endwhile; ?>
   </div>
  </div>
 </div>
</div>
<?php endif;?>