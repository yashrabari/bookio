<?php 
$widget_id = 'bwp_author_'.rand().time();
$class_col_lg = ($columns == 5) ? '2-4'  : (12/$columns);
$class_col_md = ($columns1 == 5) ? '2-4'  : (12/$columns1);
$class_col_sm = ($columns2 == 5) ? '2-4'  : (12/$columns2);
$class_col_xs = ($columns3 == 5) ? '2-4'  : (12/$columns3);
$attributes = 'col-xl-'.$class_col_lg .' col-lg-'.$class_col_md .' col-md-'.$class_col_sm .' col-'.$class_col_xs;
$term_authors = array();
if( !is_array( $author ) ){
	$category = explode( ',', $author );
}
if($author){
$term_authors = $author;
?>
<div id="<?php echo esc_attr( $widget_id ) ?>" class="bwp-author <?php echo esc_attr($layout); ?>">
	<?php if( $title1 != '') { ?>
			<div class="title_author"><?php echo ( $title1 != '' ) ? '<h2>'. esc_html( $title1 ) .'</h2>' : ''; ?></div>
	<?php }?>
	<div class="block_content row">
		<?php 
		foreach( $term_authors as $j => $term_author ) {
			$term = get_term_by( 'slug', $term_author, 'product_author' );
			if( $term ) :
			$thumb 	= ( get_term_meta( $term->term_id, 'thumbnail_bid', true ) );
			$thubnail = !empty($thumb) ? $thumb : "http://placehold.it/200x200";
			?>
			<div class="item <?php echo esc_attr($attributes) ?>">
				<div class="item-content image-position-<?php echo esc_attr($postion_image); ?>">
					<div class="item-image">
						<?php echo '<a href="'. get_term_link( $term->term_id, 'product_author' ).'"><span>'.esc_attr($j + 1).'</span><img src="'.esc_url($thubnail).'" alt="'.esc_html($term->name).'"></a>'; ?>
					</div>
					<div class="content">
						<h2 class="item-title">
							<a  href="<?php echo get_term_link( $term->term_id, 'product_author' ); ?>" ><?php echo '<span>'. esc_html( $term->name ) .'</span>'; ?></a>
						</h2>
						<div class="item-count">
							<?php echo esc_attr($term->count) .'<span>'. esc_html__(' Published Book', 'wpbingo').'</span>'; ?>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>
		<?php } ?>
	</div>
</div>
<?php } ?>