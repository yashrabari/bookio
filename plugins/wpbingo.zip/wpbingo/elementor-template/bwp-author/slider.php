<?php 
$widget_id = 'bwp_author_'.rand().time();
$term_authors = array();
if( !is_array( $author ) ){
	$category = explode( ',', $author );
}
if($author){
$term_authors = $author;
?>
<div id="<?php echo esc_attr( $widget_id ) ?>" class="bwp-author <?php echo esc_attr($layout); ?>">
	<?php if( $title1 != '') { ?>
			<div class="title_author"><?php echo ( $title1 != '' ) ? '<h2>'. esc_html( $title1 ) .'</h2>' : ''; ?></div>
	<?php }?>
	<div class="block_content">
		<div class="slider slick-carousel" data-slidesToScroll="true" data-nav="<?php echo esc_attr($show_nav);?>" data-dots="<?php echo esc_attr($show_pag);?>" data-columns4="<?php echo esc_attr($columns4); ?>" data-columns3="<?php echo esc_attr($columns3); ?>" data-columns2="<?php echo esc_attr($columns2); ?>" data-columns1="<?php echo esc_attr($columns1); ?>" data-columns1440="<?php echo $columns1440; ?>" data-columns="<?php echo esc_attr($columns); ?>">
			<?php 
			foreach( $term_authors as $j => $term_author ) {
				$j++;
				$term = get_term_by( 'slug', $term_author, 'product_author' );
				if( $term ) :
					$thumb 	= ( get_term_meta( $term->term_id, 'thumbnail_bid', true ) );
					$thubnail = !empty($thumb) ? $thumb : "http://placehold.it/200x200";
					?>
					<?php	if( ($j == 1) ||  ( $j % $item_row  == 1 ) || ( $item_row == 1 )) { ?>
						<div class="item-author">
					<?php } ?>
						<div class="item-list-author">
							<div class="item-content image-position-<?php echo esc_attr($postion_image); ?>">
								<div class="item-image">
									<?php echo '<a href="'. get_term_link( $term->term_id, 'product_author' ).'"><img src="'.esc_url($thubnail).'" alt="'.esc_html($term->name).'"></a>'; ?>
								</div>
								<div class="content">
									<h2 class="item-title">
										<a  href="<?php echo get_term_link( $term->term_id, 'product_author' ); ?>" ><?php echo '<span>'. esc_html( $term->name ) .'</span>'; ?></a>
									</h2>
									<div class="item-count">
										<?php echo esc_attr($term->count) .'<span>'. esc_html__(' Published Book', 'wpbingo').'</span>'; ?>
									</div>
								</div>
							</div>
						</div>
					<?php if( ($j == count($term_authors)) || ($j % $item_row == 0) || ($item_row == 1)){ ?>
						</div>
					<?php  } $j++;?>
				<?php endif; ?>
			<?php } ?>
		</div>
	</div>
</div>
<?php } ?>