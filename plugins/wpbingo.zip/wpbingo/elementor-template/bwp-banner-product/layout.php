<?php $arr = array('br' => array(), 'p' => array(), 'span' => array()); ?>
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $product, $woocommerce_loop, $post;
?>
<div class="bwp-widget-bannerproduct <?php echo esc_html( $layout ); ?>">
	<?php  if($product_id && $product = wc_get_product( $product_id )): ?>
		<?php  if($image): ?>	
		<div class="bg-banner">
			<div class="banner-wrapper banners">
				<div class="bwp-image<?php if ($image_hover) { ?> elementor-animation-<?php echo esc_attr($image_hover); } ?>">
					<a class="image" href="<?php echo get_permalink( $product_id );  ?>">
						<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr__("Banner Image","wpbingo"); ?>">
					</a>
				</div>
				<div class="banner-wrapper-infor">
					<div class="info">
						<h2 class="title-banner"><?php echo esc_html($title); ?></h2>
						<div class="content">
							<h3 class="product-title"><a href="<?php echo get_permalink( $product_id );  ?>"><?php echo $product->get_title(); ?></a></h3>
							<?php bookio_author_product(); ?>
							<div class="product-price"><?php echo $product->get_price_html(); ?></div>
							<div class="description">
								<?php echo ( wp_kses( $product->get_short_description(),'social' ) ) ?>
							</div>
						</div>
						<div class="product-button">
							<?php
							if(function_exists("bookio_woocommerce_template_loop_add_to_cart")){
								bookio_woocommerce_template_loop_add_to_cart();
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif;?>
	<?php endif;?>
</div>
